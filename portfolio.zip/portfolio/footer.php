<?php
/**
 * This is index of the page
 *
 * @package portfolio
 */

?>
<?php
  $facebook = empty(get_field('facebool')) ? '#' : get_field('facebool');
  $twitter = empty(get_field('twitter')) ? '#' : get_field('twitter');
  $instagram = empty(get_field('instagram')) ? '#' : get_field('instagram');
  $indeed = empty(get_field('indeed')) ? '#' : get_field('indeed');
?>
<footer class="site-footer">
      <div class="container">
        <div class="row mb-3">
          <div class="col-md-12 text-center">
            <p>
              <?php if( !empty($facebook)) : ?> 
                <a href="<?php echo $facebook;?>" class="social-item"><span class="icon-facebook2"></span></a>
              <?php endif; ?>  
              <?php if( !empty($twitter)) : ?>  
                <a href="<?php echo $twitter;  ?>" class="social-item"><span class="icon-twitter"></span></a>
              <?php endif; ?> 
              <?php if( !empty($instagram)) : ?> 
                 <a href="<?php echo $instagram; ?>" class="social-item"><span class="icon-instagram2"></span></a>
              <?php endif; ?> 
              <?php if( !empty($indeed)) : ?> 
                <a href="<?php echo $indeed; ?>" class="social-item"><span class="icon-linkedin2"></span></a>
              <?php endif; ?> 
              <!--<a href="<?php echo $facebook ?>" class="social-item"><span class="icon-vimeo"></span></a>-->
            </p>
          </div>
        </div>
        <div class="row">
            <p class="col-12 text-center">
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy; <script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" class="text-primary">Colorlib</a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
        </div>
      </div>
</footer>