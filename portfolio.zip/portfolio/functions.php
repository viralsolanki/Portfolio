<?php
/**
 * This is index of the page
 *
 * @package portfolio
 */

?>
<?php
function portfolio_setup(){
	add_theme_support( 'post-thumbnails' );
}
add_action( 'after_setup_theme', 'portfolio_setup' );

function enqueue_script(){
	
	wp_enqueue_style( 'portfolio-style', get_stylesheet_uri(), array(), wp_rand( 111, 9999 ) );

	wp_deregister_script( 'jquery' );

		wp_register_script( 'jquery', get_template_directory_uri() . '/lib/jquery.js', '20151215', true, '' );

	wp_enqueue_script( 'jquery' );

	wp_enqueue_script(
		'bootstrap_js',
		get_template_directory_uri() . '/lib/bootstrap.min.js',
		'20151215',
		true);
	

	wp_enqueue_script(
		'jquery_min',
		get_template_directory_uri() . '/js/vendor/jquery.min.js',
		'20151215',
		true
	);

	wp_enqueue_style( 'bootstrap_css', get_template_directory_uri() . '/css/bootstrap.css', '1.0' );

	wp_enqueue_style( 'animate_css', get_template_directory_uri() . '/css/animate.css', '1.0' );
	wp_enqueue_style( 'flexslider_css', get_template_directory_uri() . '/css/flexslider.css', '1.0' );
	wp_enqueue_style( 'style_css', get_template_directory_uri() . '/fonts/icomoon/style.css', '1.0' );
	wp_enqueue_style( 'offical_style_css', get_template_directory_uri() . '/css/offical_style.css', '1.0' );

	/* <script src="js/vendor/jquery.min.js"></script>
    <script src="js/vendor/popper.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    
    <script src="js/vendor/jquery.easing.1.3.js"></script>
    <script src="js/vendor/jquery.stellar.min.js"></script>
    <script src="js/vendor/jquery.waypoints.min.js"></script>

    <script src="https://unpkg.com/isotope-layout@3/dist/isotope.pkgd.min.js"></script>
    <script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
    <script src="js/custom.js"></script>

    <!-- Google Map -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
    <script src="js/google-map.js"></script>*/

	wp_enqueue_script(
		'popper_min',
		get_template_directory_uri() . '/js/vendor/popper.min.js',
		'20151215',
		true
	);
	
	wp_enqueue_script(
		'jquery_easing',
		get_template_directory_uri() . '/js/vendor/jquery.easing.1.3.js',
		'20151215',
		true
	);
	
	wp_enqueue_script(
		'jquery_stellar',
		get_template_directory_uri() . '/js/vendor/jquery.stellar.min.js',
		'20151215',
		true
	);
	
	wp_enqueue_script(
		'jquery_waypoints',
		get_template_directory_uri() . '/js/vendor/jquery.waypoints.min.js',
		'20151215',
		true
	);
	
	wp_enqueue_script(
		'isotope_pkgd',
		'https://unpkg.com/isotope-layout@3/dist/isotope.pkgd.min.js',
		'20151215',
		true
	);
	
	wp_enqueue_script(
		'custom_js',
		get_template_directory_uri() . '/js/custom.js',
		'20151215',
		true
	);
	
	wp_enqueue_script(
		'google_maps',
		'https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false',
		'20151215',
		true
	);
	
	wp_enqueue_script(
		'google-map',
		get_template_directory_uri() . '/js/google-map.js',
		'20151215',
		true
	);

}

add_action( 'wp_enqueue_scripts', 'enqueue_script' );