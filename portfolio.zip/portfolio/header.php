<?php
/**
 * This is index of the page
 *
 * @package portfolio
 */

?>

<!DOCTYPE html>

<html lang="en" style="margin-top: 0px !important">
  <head>
    <title>Alias Colorlib &mdash; One Page Template for Personal/CV Website</title>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,700" rel="stylesheet">
    <?php wp_head(); ?>
    
  </head>

